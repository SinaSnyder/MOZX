public enum Turn {
    LEFT, STRAIGHT, RIGHT;
}
